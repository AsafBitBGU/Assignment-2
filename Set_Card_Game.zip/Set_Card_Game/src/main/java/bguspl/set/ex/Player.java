package bguspl.set.ex;

import java.util.PriorityQueue;
import java.util.Random;
import java.util.logging.Level;

import bguspl.set.Env;

/**
 * This class manages the players' threads and data
 *
 * @inv id >= 0
 * @inv score >= 0
 */
public class Player implements Runnable {

    /**
     * The game environment object.
     */
    private final Env env;

    /**
     * The games dealer;
     */
    private final Dealer dealer;
    /**
     * Game entities.
     */
    private final Table table;

    /**
     * The id of the player (starting from 0).
     */
    public final int id;

    /**
     * The thread representing the current player.
     */
    private Thread playerThread;

    /**
     * The thread of the AI (computer) player (an additional thread used to generate key presses).
     */
    private Thread aiThread;

    /**
     * True iff the player is human (not a computer player).
     */
    private final boolean human;

    /**
     * True iff game should be terminated due to an external event.
     */
    private volatile boolean terminate;

    /**
     * The current score of the player.
     */
    private int score;

    // Queue of players actions.
    private PriorityQueue<Integer> actions;

    // Boolean if the player thinks he has a set
    public boolean maybeSet;

    // Boolean if the player diserves a point
    public boolean shouldGetAPoint;

    //Boolean if the player diserves a penalty
    public boolean shouldGetAPenalty;

    /**
     * The class constructor.
     *
     * @param env    - the environment object.
     * @param dealer - the dealer object.
     * @param table  - the table object.
     * @param id     - the id of the player.
     * @param human  - true iff the player is a human player (i.e. input is provided manually, via the keyboard).
     */
    public Player(Env env, Dealer dealer, Table table, int id, boolean human) {
        this.env = env;
        this.dealer = dealer;
        this.table = table;
        this.id = id;
        this.human = human;
        this.actions = new PriorityQueue<Integer>(3);
        this.maybeSet = false;
        this.shouldGetAPoint = false;
        this.shouldGetAPenalty = false;
    }

    /**
     * The main player thread of each player starts here (main loop for the player thread).
     */
    @Override
    public void run() {
        playerThread = Thread.currentThread();
        env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + "starting.");
        if (!human) createArtificialIntelligence();

        while (!terminate) {
            // TODO implement main player loop
            point();
            penalty();
        }
        if (!human) try { aiThread.join(); } catch (InterruptedException ignored) {}
        env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + " terminated.");
    }

    /**
     * Creates an additional thread for an AI (computer) player. The main loop of this thread repeatedly generates
     * key presses. If the queue of key presses is full, the thread waits until it is not full.
     */
    private void createArtificialIntelligence() {
        // note: this is a very very smart AI (!)
        aiThread = new Thread(() -> {
            env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + " starting.");
            while (!terminate) {
                // TODO implement player key press simulator
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {}
                point();
                penalty();
                Random rand = new Random();
                while(actions.size() != 2){
                    int slot = rand.nextInt(env.config.tableSize);
                    keyPressed(slot);
                }
                

                try {
                    synchronized (this) { wait(); }
                } catch (InterruptedException ignored) {}
            }
            env.logger.log(Level.INFO, "Thread " + Thread.currentThread().getName() + " terminated.");
        }, "computer-" + id);
        aiThread.start();
    }

    /**
     * Called when the game should be terminated due to an external event.
     */
    public void terminate() {
        // TODO implement
        this.terminate = true;
    }

    /**
     * This method is called when a key is pressed.
     *
     * @param slot - the slot corresponding to the key pressed.
     */
    public void keyPressed(int slot) {
        // TODO implement
        if (!shouldGetAPenalty & !shouldGetAPoint){
            if (actions.size() <= 2 & !actions.contains(slot)){
            table.placeToken(id, slot);
            actions.add(slot);
                if (actions.size() == 3){
                  maybeSet = true;
                  dealer.playersWithSets.add(this);
            }
            }
        
            else if (actions.contains(slot)){
                table.removeToken(id, slot);
                actions.remove(slot);
            }
        }
        
    }

    /**
     * Award a point to a player and perform other related actions.
     *
     * @post - the player's score is increased by 1.
     * @post - the player's score is updated in the ui.
     */
    public void point() {
        // TODO implement
        int ignored = table.countCards(); // this part is just for demonstration in the unit tests
        if (shouldGetAPoint){
            env.ui.setScore(id, ++score);
            this.pointFreeze();
            shouldGetAPoint = false;
        }
    }

    // Pause the player after a correct set
    public void pointFreeze(){
        freezeAndCountSeconds(2000);

        try {
            Thread.sleep(env.config.pointFreezeMillis);
        } catch (InterruptedException e) {}
    }

    /**
     * Penalize a player and perform other related actions.
     */
    public void penalty() {
        // TODO implement
        if (shouldGetAPenalty){
            penaltyFreeze();
            freezeAndCountSeconds(4000);
            shouldGetAPenalty = false;
        }
        
    }

    public void penaltyFreeze(){
        freezeAndCountSeconds(4000);

        try {
            Thread.sleep(env.config.penaltyFreezeMillis);
        } catch (InterruptedException e) {}

    }

    private void freezeAndCountSeconds(long millies){
        long currTime = System.currentTimeMillis();
        long second = currTime - System.currentTimeMillis() + millies;
        while(second >= 0){
            env.ui.setFreeze(id, second);
            second = currTime - System.currentTimeMillis() + millies;
        }
    }

    public int getScore() {
        return score;
    }


    public int[] getCardArray(){
        Integer[] pqArr = actions.toArray(new Integer[3]);
        int[] arr = new int[pqArr.length];
        for (int i=0; i <= pqArr.length - 1; ++i){
            arr[i] = table.slotToCard[pqArr[i]];
        } 
        return arr;
    }

    public void noSet(){
        maybeSet = false;
    }

    public boolean isInActions(int slot){
        if (actions.contains(slot)){
            return true;
        }
        else{
            return false;
        }
    }
    
    public void removeFromActions(int slot){
        actions.remove(slot);
    }
 }
