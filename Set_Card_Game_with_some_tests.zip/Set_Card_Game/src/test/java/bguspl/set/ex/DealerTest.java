package bguspl.set.ex;

import org.junit.jupiter.api.Test;

public class DealerTest {
    @Test
    void testAddPlayersWithSet() {

    }
}
